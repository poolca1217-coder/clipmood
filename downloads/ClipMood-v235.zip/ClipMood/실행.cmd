@start "" "%~dp0ClipMood.html"
